import 'package:flutter/material.dart';

import 'dice.dart';

void main() {
  runApp(const DiceApp());
}

class DiceApp extends StatelessWidget {
  const DiceApp({super.key}); // Standard constructor

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    home: const DiceScreen(),
    title: 'Rolling Dice App',
  );
}

class DiceScreen extends StatelessWidget {
  const DiceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            colors: [
              Colors.deepOrangeAccent,
              Colors.lightGreenAccent,
              Colors.yellowAccent,
            ],
            radius: 1,
          ),
        ),
        alignment: Alignment.center,

        child: SingleChildScrollView(child: Dice()),
      ),
    );
  }
}
