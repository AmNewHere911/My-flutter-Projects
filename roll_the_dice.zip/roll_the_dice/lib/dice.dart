import 'dart:math';
import 'package:flutter/material.dart';

class Dice extends StatefulWidget {
  const Dice({super.key});

  @override
  // createState() should ONLY return the State object
  State<Dice> createState() => _DiceState();
}

class _DiceState extends State<Dice> {
  // 1. Initialize state variables here
  int leftDice = 1;  // Changed variable names to camelCase for convention
  int rightDice = 1; // Changed variable names to camelCase for convention

  // 2. Method to change state and update UI
  void rollDice() { // Corrected typo from "rollDice"
    setState(() { // Call setState to trigger UI rebuild
      leftDice = Random().nextInt(6) + 1;  // Generates 1-6
      rightDice = Random().nextInt(6) + 1; // Generates 1-6
      print('Dice rolled: Left: $leftDice, Right: $rightDice');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text(
          'Roll The Dice',
          style: TextStyle(
            fontSize: 30,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 30),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 30),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.5),
            borderRadius: BorderRadius.circular(25),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 15,
                offset: const Offset(5, 5),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              // 3. Ensure these assets exist and are declared in pubspec.yaml
              // e.g., assets/photo/1.jpg, assets/photo/2.jpg etc.
              Expanded( // Using Expanded to give images defined space
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Image.asset('photo/$leftDice.jpg', height: 100, width: 100),
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Image.asset('photo/$rightDice.jpg', height: 100, width: 100),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 50),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 13),
            textStyle: const TextStyle(fontSize: 20),
            backgroundColor: Colors.lightGreenAccent,
            foregroundColor: Colors.black87,
            shadowColor: Colors.black87,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(50),
            ),
          ),
          // 4. Call the rollDice method (defined in _DiceState) in onPressed
          onPressed: rollDice,
          child: const Text(
            'Roll The Dice',
            style: TextStyle(
              fontSize: 35, // Adjusted slightly for potential fit
              fontWeight: FontWeight.bold,
              color: Colors.black54,
            ),
          ),
        )
      ],
    );
  }
}