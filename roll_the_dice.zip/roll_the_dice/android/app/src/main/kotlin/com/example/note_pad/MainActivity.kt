package com.example.note_pad

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
