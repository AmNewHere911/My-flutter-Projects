package com.example.whatsapp_messenger

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
