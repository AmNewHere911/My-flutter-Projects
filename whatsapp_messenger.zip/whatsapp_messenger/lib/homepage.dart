import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(120),
          child: AppBar(
            elevation: 0,
            title: const Padding(
              padding: EdgeInsets.only(top: 10.0),
              child: Text(
                "WhatsApp",
                style: TextStyle(
                  fontSize: 21,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            actions: [
              Padding( // Outer padding for the IconButton's position in AppBar
                padding: const EdgeInsets.only(top: 10, right: 10),
                child: IconButton(
                  // IconButton's own padding can be EdgeInsets.zero if you only want the inner Icon padding
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(), // Optional: to remove default IconButton min size
                  icon: Padding( // Wrap Icon with Padding
                    padding: const EdgeInsets.only(top: 10, right: 20), // Your desired padding for the Icon
                    child: Icon(
                      Icons.search,
                      size: 30,
                      color: Colors.white,
                      shadows: <Shadow>[
                        Shadow(
                          offset: Offset(1.0, 1.0),
                          blurRadius: 3.0,
                          color: Colors.black54,
                        ),
                      ],
                    ),
                  ),
                  onPressed: () {
                    print("Search icon pressed");
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 0, right: 5),
                child: PopupMenuButton<String>(
                  icon: const Icon(Icons.more_vert, size: 28, color: Colors.white),
                  onSelected: (value) {
                    print("Selected: $value");
                  },
                  itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
                    const PopupMenuItem<String>(
                      value: 'new_group',
                      child: Text('New group'),
                    ),
                    const PopupMenuItem<String>(
                      value: 'new_broadcast',
                      child: Text('New broadcast'),
                    ),
                    const PopupMenuItem<String>(
                      value: 'linked_devices',
                      child: Text('Linked devices'),
                    ),
                    const PopupMenuItem<String>(
                      value: 'starred_messages',
                      child: Text('Starred messages'),
                    ),
                    const PopupMenuItem<String>(
                      value: 'settings',
                      child: Text('Settings'),
                    ),
                  ],
                ),
              ),
            ],
            bottom: const TabBar(
              indicatorColor: Colors.white,
              labelColor: Colors.white,
              unselectedLabelColor: Colors.white70,
              tabs: [
                Tab(icon: Icon(Icons.camera_alt), text: "Camera"),
                Tab(text: "CHATS"),
                Tab(text: "STATUS"),
                Tab(text: "CALLS"),
              ],
            ),
          ),
        ),
        body: const TabBarView(
          children: [
            Center(child: Text("Camera Tab Content")),
            Center(child: Text("Chats Tab Content")),
            Center(child: Text("Status Tab Content")),
            Center(child: Text("Calls Tab Content")),
          ],
        ),
      ),
    );
  }
}